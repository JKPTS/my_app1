// ===== FILE: main/rgb_led.h =====
#pragma once

#include <stdint.h>
#include "esp_err.h"

// Simple 3-channel PWM RGB LED driver (LEDC)
// Default wiring: common-anode, active-low (GPIO drives cathode LOW to turn ON)

// Default pins (change these if you want different GPIOs)
// NOTE: Current wiring (user): R=GPIO1, G=GPIO2, B=GPIO15.
// You can override these with build flags (-DRGB_LED_GPIO_R=..., etc.).
#ifndef RGB_LED_GPIO_R
#define RGB_LED_GPIO_R 1
#endif
#ifndef RGB_LED_GPIO_G
#define RGB_LED_GPIO_G 2
#endif
#ifndef RGB_LED_GPIO_B
#define RGB_LED_GPIO_B 15
#endif

// 1 = common-anode (active-low), 0 = common-cathode (active-high)
#ifndef RGB_LED_COMMON_ANODE
#define RGB_LED_COMMON_ANODE 1
#endif

// Init LEDC and GPIOs
esp_err_t rgb_led_init(void);

// Brightness percent 0..100 (applied on top of RGB values)
void rgb_led_set_brightness(uint8_t percent);
uint8_t rgb_led_get_brightness(void);

// Set RGB (0..255 each)
void rgb_led_set_rgb(uint8_t r, uint8_t g, uint8_t b);

// Set RGB using 0xRRGGBB
void rgb_led_set_hex(uint32_t hex_rgb);

// Get last set color (0xRRGGBB)
uint32_t rgb_led_get_hex(void);
