// ===== FILE: main/rgb_store.c =====

#include "rgb_store.h"

#include "esp_log.h"
#include "nvs.h"
#include "nvs_flash.h"

#include "config_store.h"
#include "rgb_led.h"

static const char *TAG = "RGBSTORE";

#define RGB_NVS_NAMESPACE "cfg"
#define RGB_NVS_KEY       "rgb_hex"

static uint32_t s_rgb_hex = 0xFFFFFF; // default white

esp_err_t rgb_store_init(void)
{
    esp_err_t err;

    // Ensure RGB LED driver is ready (safe to call multiple times)
    err = rgb_led_init();
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "rgb_led_init failed: %s", esp_err_to_name(err));
        return err;
    }

    nvs_handle_t h;
    err = nvs_open(RGB_NVS_NAMESPACE, NVS_READONLY, &h);
    if (err == ESP_OK) {
        uint32_t v = 0;
        err = nvs_get_u32(h, RGB_NVS_KEY, &v);
        nvs_close(h);
        if (err == ESP_OK) {
            s_rgb_hex = v & 0xFFFFFF;
        } else {
            // key missing is normal
            s_rgb_hex = 0xFFFFFF;
        }
    } else {
        // If NVS not ready yet, keep default
        s_rgb_hex = 0xFFFFFF;
        err = ESP_OK;
    }

    ESP_LOGI(TAG, "loaded rgb #%06lx", (unsigned long)s_rgb_hex);
    return ESP_OK;
}

void rgb_store_apply(void)
{
    uint8_t br = config_store_get_led_brightness();
    rgb_led_set_brightness(br);
    rgb_led_set_hex(s_rgb_hex);
}

uint32_t rgb_store_get_hex(void)
{
    return s_rgb_hex;
}

esp_err_t rgb_store_set_hex(uint32_t hex_rgb)
{
    s_rgb_hex = hex_rgb & 0xFFFFFF;

    nvs_handle_t h;
    esp_err_t err = nvs_open(RGB_NVS_NAMESPACE, NVS_READWRITE, &h);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "nvs_open failed: %s", esp_err_to_name(err));
        rgb_store_apply();
        return err;
    }

    err = nvs_set_u32(h, RGB_NVS_KEY, s_rgb_hex);
    if (err == ESP_OK) {
        err = nvs_commit(h);
    }
    nvs_close(h);

    if (err != ESP_OK) {
        ESP_LOGE(TAG, "failed to save rgb: %s", esp_err_to_name(err));
    }

    rgb_store_apply();
    return err;
}
