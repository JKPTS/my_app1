// ===== FILE: main/rgb_store.h =====
#pragma once

#include <stdint.h>
#include "esp_err.h"

// Stores a single RGB color (0xRRGGBB) in NVS and applies it via rgb_led.

esp_err_t rgb_store_init(void);

// Apply stored color + current config_store brightness to the RGB LED.
void rgb_store_apply(void);

uint32_t rgb_store_get_hex(void);

// Set new color (0xRRGGBB), save to NVS, and apply.
esp_err_t rgb_store_set_hex(uint32_t hex_rgb);

