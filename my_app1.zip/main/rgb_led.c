// ===== FILE: main/rgb_led.c =====

#include "rgb_led.h"

#include "esp_log.h"
#include "driver/ledc.h"

static const char *TAG = "RGBLED";

#define RGB_LEDC_TIMER      LEDC_TIMER_0
#define RGB_LEDC_MODE       LEDC_LOW_SPEED_MODE
#define RGB_LEDC_FREQ_HZ    5000
#define RGB_LEDC_DUTY_RES   LEDC_TIMER_12_BIT
#define RGB_LEDC_DUTY_MAX   4095

static uint8_t s_brightness_percent = 100;
static uint32_t s_hex_rgb = 0x000000;

static inline uint32_t scale_u8_to_u12(uint8_t v)
{
    // Map 0..255 -> 0..4095
    return ((uint32_t)v * RGB_LEDC_DUTY_MAX + 127) / 255;
}

static inline uint32_t apply_brightness_u12(uint32_t duty_u12)
{
    // brightness 0..100
    return (duty_u12 * (uint32_t)s_brightness_percent) / 100;
}

static esp_err_t set_channel(ledc_channel_t ch, uint32_t duty_u12)
{
#if RGB_LED_COMMON_ANODE
    // common-anode: active-low => invert duty
    duty_u12 = RGB_LEDC_DUTY_MAX - duty_u12;
#endif

    ESP_ERROR_CHECK(ledc_set_duty(RGB_LEDC_MODE, ch, duty_u12));
    return ledc_update_duty(RGB_LEDC_MODE, ch);
}

esp_err_t rgb_led_init(void)
{
    // Timer config
    ledc_timer_config_t timer_cfg = {
        .speed_mode       = RGB_LEDC_MODE,
        .duty_resolution  = RGB_LEDC_DUTY_RES,
        .timer_num        = RGB_LEDC_TIMER,
        .freq_hz          = RGB_LEDC_FREQ_HZ,
        .clk_cfg          = LEDC_AUTO_CLK,
    };

    esp_err_t err = ledc_timer_config(&timer_cfg);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "ledc_timer_config failed: %s", esp_err_to_name(err));
        return err;
    }

    const struct {
        ledc_channel_t ch;
        int gpio;
    } map[3] = {
        { LEDC_CHANNEL_0, RGB_LED_GPIO_R },
        { LEDC_CHANNEL_1, RGB_LED_GPIO_G },
        { LEDC_CHANNEL_2, RGB_LED_GPIO_B },
    };

    for (int i = 0; i < 3; i++) {
        ledc_channel_config_t ch_cfg = {
            .gpio_num   = map[i].gpio,
            .speed_mode = RGB_LEDC_MODE,
            .channel    = map[i].ch,
            .intr_type  = LEDC_INTR_DISABLE,
            .timer_sel  = RGB_LEDC_TIMER,
            .duty       = RGB_LEDC_DUTY_MAX, // OFF for common-anode after invert; will be set correctly below
            .hpoint     = 0,
            .flags      = { .output_invert = 0 },
        };

        err = ledc_channel_config(&ch_cfg);
        if (err != ESP_OK) {
            ESP_LOGE(TAG, "ledc_channel_config ch=%d gpio=%d failed: %s", (int)map[i].ch, map[i].gpio, esp_err_to_name(err));
            return err;
        }
    }

    // Start with OFF
    rgb_led_set_rgb(0, 0, 0);

    ESP_LOGI(TAG, "rgb ledc ready (R=%d G=%d B=%d) %s", RGB_LED_GPIO_R, RGB_LED_GPIO_G, RGB_LED_GPIO_B,
#if RGB_LED_COMMON_ANODE
             "active-low common-anode"
#else
             "active-high common-cathode"
#endif
    );

    return ESP_OK;
}

void rgb_led_set_brightness(uint8_t percent)
{
    if (percent > 100) percent = 100;
    s_brightness_percent = percent;
    rgb_led_set_hex(s_hex_rgb);
}

uint8_t rgb_led_get_brightness(void)
{
    return s_brightness_percent;
}

void rgb_led_set_rgb(uint8_t r, uint8_t g, uint8_t b)
{
    uint32_t ru12 = apply_brightness_u12(scale_u8_to_u12(r));
    uint32_t gu12 = apply_brightness_u12(scale_u8_to_u12(g));
    uint32_t bu12 = apply_brightness_u12(scale_u8_to_u12(b));

    // Best-effort; if a channel update fails, still try others
    (void)set_channel(LEDC_CHANNEL_0, ru12);
    (void)set_channel(LEDC_CHANNEL_1, gu12);
    (void)set_channel(LEDC_CHANNEL_2, bu12);

    s_hex_rgb = ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
}

void rgb_led_set_hex(uint32_t hex_rgb)
{
    uint8_t r = (hex_rgb >> 16) & 0xFF;
    uint8_t g = (hex_rgb >> 8) & 0xFF;
    uint8_t b = hex_rgb & 0xFF;
    rgb_led_set_rgb(r, g, b);
}

uint32_t rgb_led_get_hex(void)
{
    return s_hex_rgb;
}
