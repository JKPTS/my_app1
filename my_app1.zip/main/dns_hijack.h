﻿#pragma once
void dns_hijack_start(void);
