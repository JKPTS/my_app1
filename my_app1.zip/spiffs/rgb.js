// ===== FILE: spiffs/rgb.js =====
async function apiGet(url) {
  const r = await fetch(url, { cache: "no-store" });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}
async function apiPost(url, obj) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(obj),
  });
  if (!r.ok) throw new Error(await r.text());
  return r.json();
}

const pick = document.getElementById("pick");
const btn  = document.getElementById("btnSave");
const st   = document.getElementById("status");

function setStatus(msg, ok=true){
  st.textContent = msg || "";
  st.style.color = ok ? "#0a0" : "#c00";
}

async function loadCurrent(){
  try{
    const j = await apiGet("/api/rgb");
    if (j && j.hex) pick.value = j.hex;
    setStatus("loaded ✅");
  }catch(e){
    setStatus("load failed: " + e.message, false);
  }
}

btn.addEventListener("click", async ()=>{
  try{
    btn.disabled = true;
    setStatus("saving…");
    const hex = pick.value || "#ffffff";
    await apiPost("/api/rgb", { hex });
    setStatus("saved ✅");
  }catch(e){
    setStatus("save failed: " + e.message, false);
  }finally{
    btn.disabled = false;
  }
});

loadCurrent();
